local u = HodorReflexes.users

u["@Nightingale707"] = {"Gale", "|cf54293Gale|r", "HodorReflexes/users/luck/gale.dds"}
u["@Galadriel67"] = {"Galadriel", "|cffbc00Galadriel|r", "HodorReflexes/users/luck/galadriel.dds"}
u["@Tsu_Namii"] = {"Tsu", "|c49e1f2Tsu|r", "HodorReflexes/users/luck/tsu.dds"}
u["@Hantelhans"] = {"Hans", "|cf59342Hans|r", "HodorReflexes/users/luck/hans.dds"}
u["@MuSE_nr1"] = {"MuSE", "|cFF4F00MuSE|r", "HodorReflexes/users/luck/muse.dds"}
u["@Ikkito37"] = {"Ikkito", "|c255fbaIkkito|r", "HodorReflexes/users/luck/ikkito.dds"}
u["@ICrimsonI"] = {"Crimson", "|c14BCC1Crismo|r", "HodorReflexes/users/luck/crimson.dds"}
u["@Shaeogorath"] = {"Sheo", "|c991CF6Sheo|r", "HodorReflexes/users/luck/sheo.dds"}
u["@w00tzor"] = {"w00t", "|cf56f42w00t|r", "HodorReflexes/users/luck/w00t.dds"}
u["@Manzarken"] = {"Manzarken", "|c3243c7Manzarken|r", "HodorReflexes/users/luck/manzarken.dds"}
u["@Secilina"] = {"Bob", "|c39e825Bob|r", "HodorReflexes/users/luck/bob.dds"}
u["@Kuraiij"] = {"Kura", "|ce34bd5Kura|r", "HodorReflexes/users/luck/kuraiij.dds"}
u["@Porkkanalaatikko"] = {"Porky", "|c00fffePorky|r", "HodorReflexes/users/luck/porky.dds"}