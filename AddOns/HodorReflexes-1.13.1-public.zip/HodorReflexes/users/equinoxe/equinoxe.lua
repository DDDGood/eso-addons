local u = HodorReflexes.users
--local a = HodorReflexes.anim.users

u["@dov118"] = {"dov118", "|c49604fl|r|c3f3f1fo|r|ca3a499k|r|c03480ai|r", "HodorReflexes/users/equinoxe/dov1182.dds"}
u["@Wyrelll"] = {"Wyrelll", "|c0060ffWy|r|cffffffre|r|cff0000lll|r", "HodorReflexes/users/equinoxe/Wyrelll.dds"}
u["@Olemike"] = {"Olemike", "|cb80113Olemike|r", "HodorReflexes/users/equinoxe/Olemike.dds"}
u["@Matbax"] = {"Matbax", "|cff00f6L|r|ca800ffe|r |c0030ffM|r|c00ffc0a|r|c00ff06t|r|cfff000b|r|cff8400a|r|cff000ax|r", "HodorReflexes/users/equinoxe/Matbax.dds"}
u["@minou29"] = {"Minou", "|c3b7e86Minou|r", "HodorReflexes/users/equinoxe/minou29.dds"}
u["@Kalior"] = {"Kalior", "|c0060ffKa|r|cffffffli|r|cff0000or|r", "HodorReflexes/users/equinoxe/Kalior.dds"}
u["@grovex_fr"] = {"grovex_fr", "|cffd636grovex_fr|r", "HodorReflexes/users/equinoxe/grovex_fr.dds"}
