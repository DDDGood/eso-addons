local u = HodorReflexes.users

u["@SloppyChef"] = {"Chef", "Chef", "HodorReflexes/users/ua/chef.dds"}
u["@Slafo"] = {"Schäffo", "|cDB7093Schäffo|r", "HodorReflexes/users/ua/slafo.dds"}
u["@FreshKot"] = {"Fresh", "Fresh", "HodorReflexes/users/ua/fresh.dds"}
u["@qwertzuiop0815"] = {"Fried", "Fried", "HodorReflexes/users/ua/fried.dds"}
u["@AOEGU"] = {"AOEGU", "|c04B404AOEGU|r", "HodorReflexes/users/ua/aoegu2.dds"}
u["@Kokapi"] = {"Kokapi", "Kokapi", "HodorReflexes/users/ua/kokapi.dds"}
u["@Julian001"] = {"Julian", "|cC90000Julian|r", "HodorReflexes/users/ua/julian.dds"}
u["@Stormitor"] = {"Storm", "|c87CEEBStorm|r", "HodorReflexes/users/ua/storm.dds"}
u["@Baumlaus"] = {"Baumi", "|cFF1493Baumi|r", "HodorReflexes/users/ua/baumi.dds"}
u["@pyromaaniac"] = {"PYRO", "|ce63e00P|r|cff4500Y|r|cff581aR|r|cff7d4dO|r", "HodorReflexes/users/ua/pyro.dds"}
u["@DerFrostieee"] = {"Frostie", "Frostie", "HodorReflexes/users/ua/frostie.dds"}
u["@l0tte"] = {"Lotte", "|c00FFFFLotte|r", "HodorReflexes/users/ua/l0tte.dds"}
u["@L0tte"] = {"Lotte", "|c00FFFFLotte|r", "HodorReflexes/users/ua/l0tte.dds"}
u["@Mjaues"] = {"MJ", "|c228B22MJ|r", "HodorReflexes/users/ua/mj.dds"}
u["@Helvana"] = {"Helvana", "Helvana", "HodorReflexes/users/ua/helvana2.dds"}
u["@TingleTony"] = {"Tony", "|c96d7ffTony|r", "HodorReflexes/users/ua/tingletony.dds"}