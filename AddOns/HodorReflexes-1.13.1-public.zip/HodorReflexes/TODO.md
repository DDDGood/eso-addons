# TODO

## priority high:
- add idle packet that discribes the current ultimates & their needed ult points
  - out of combat only ... every second packet
  - at the start of combat

## priority mid:
- integrity checks
- add compact table for sharing ultimates

## priority low:

## just thoughts:
- adding Hodor icons to RectOver TargetFrame instead of CP symbol ???
